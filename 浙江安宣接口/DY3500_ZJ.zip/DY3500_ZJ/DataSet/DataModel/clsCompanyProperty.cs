using System;

namespace DYSeriesDataSet
{
	/// <summary>
	/// clsCompanyProperty ��ժҪ˵����
	/// </summary>
	public class clsCompanyProperty
	{
		public clsCompanyProperty()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}

		private string _CompanyProperty;
		private bool _IsReadOnly;
		private bool _IsLock;
		private string _Remark;

		public string CompanyProperty
		{
			set
			{
				_CompanyProperty=value;
			}
			get
			{
				return _CompanyProperty;
			}		
		}

		public bool IsReadOnly
		{
			set
			{
				_IsReadOnly=value;
			}
			get
			{
				return _IsReadOnly;
			}		
		}
		public bool IsLock
		{
			set
			{
				_IsLock=value;
			}
			get
			{
				return _IsLock;
			}		
		}
		public string Remark
		{
			set
			{
				_Remark=value;
			}
			get
			{
				return _Remark;
			}		
		}	
	}
}

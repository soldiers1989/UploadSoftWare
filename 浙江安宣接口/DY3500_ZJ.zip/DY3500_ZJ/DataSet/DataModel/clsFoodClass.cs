using System;

namespace DYSeriesDataSet
{
	/// <summary>
	/// clsFoodClass ��ժҪ˵����
	/// </summary>
	public class clsFoodClass
	{
		private string _SysCode;
		private string _StdCode;
		private string _Name;
		private string _ShortCut;
		private string _CheckLevel;
		private string _CheckItemCodes;
		private string _CheckItemValue;
		private bool _IsReadOnly;
		private bool _IsLock;
		private string _Remark;
		private string _FoodProperty;

		public clsFoodClass()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}

		public string SysCode
		{
			set
			{
				_SysCode=value;
			}
			get
			{
				return _SysCode;
			}
		}
		public string StdCode
		{
			set
			{
				_StdCode=value;
			}
			get
			{
				return _StdCode;
			}		
		}
		public string Name
		{
			set
			{
				_Name=value;
			}
			get
			{
				return _Name;
			}		
		}
		public string ShortCut
		{
			set
			{
				_ShortCut=value;
			}
			get
			{
				return _ShortCut;
			}		
		}
		public string CheckLevel
		{
			set
			{
				_CheckLevel=value;
			}
			get
			{
				return _CheckLevel;
			}		
		}
		public string CheckItemCodes
		{
			set
			{
				_CheckItemCodes=value;
			}
			get
			{
				return _CheckItemCodes;
			}		
		}
		public string CheckItemValue
		{
			set
			{
				_CheckItemValue=value;
			}
			get
			{
				return _CheckItemValue;
			}		
		}
		public bool IsReadOnly
		{
			set
			{
				_IsReadOnly=value;
			}
			get
			{
				return _IsReadOnly;
			}		
		}
		public bool IsLock
		{
			set
			{
				_IsLock=value;
			}
			get
			{
				return _IsLock;
			}		
		}
		public string Remark
		{
			set
			{
				_Remark=value;
			}
			get
			{
				return _Remark;
			}		
		}
		public string FoodProperty
		{
			set
			{
				_FoodProperty=value;
			}
			get
			{
				return _FoodProperty;
			}		
		}
	}
}

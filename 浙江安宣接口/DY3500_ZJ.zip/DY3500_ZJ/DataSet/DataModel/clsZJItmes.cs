﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DYSeriesDataSet.DataModel
{
    public class clsZJItmes
    {
        private int id = 0;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        private string _itemName = string.Empty;

        public string itemName
        {
            get { return _itemName; }
            set { _itemName = value; }
        }

        private string _itemCode = string.Empty;

        public string itemCode
        {
            get { return _itemCode; }
            set { _itemCode = value; }
        }

    }
}

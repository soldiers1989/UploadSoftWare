﻿using System;

namespace AIO
{
    [Serializable]
    public class ItemsAdapter
    {
        public string stcode = string.Empty;
        public string ItemDes = string.Empty;
        public string StandardValue = string.Empty;
        public string Unit = string.Empty;
        public string DemarcateInfo = string.Empty;
        public bool Create = false;
    }
}
